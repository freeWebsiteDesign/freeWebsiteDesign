



::Focus

	Available on: https://freeWebsite.Design
	Created by: Sajaan Matharu | https://matharu.io | @matharuio

	Trying Out An Unique Interface that helps to showcase an artists 2 most important elements: their work and their name. Designed for modern browsers on modern devices. Colors are changeable through css and js respectively.
 
	Comments, questions, bugs or feedback?
	Message me on twitter @matharuio, or through the contact link on https://freeWebsite.Design. 



License ------

	- Licensed Via Creative Commons Attribution 4.0 International
	- https://creativecommons.org/licenses/by/4.0/legalcode




Credit ------

	Thanks to everybody involved for the time and energy you all put into your respective works <3.

	Libraries
		JS
		- https://jquery.com/
		- https://greensock.com/gsap

		CSS
		- https://necolas.github.io/normalize.css/
	

	Icons
		- https://fontawesome.com/


	Images
		- Paul Hanakoa
		- https://unsplash.com/@paul_

	Email
		- https://formspree.io/		


	Fonts
		- https://fonts.google.com
	

	