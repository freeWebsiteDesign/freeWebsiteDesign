


::Atmos

	Available on: https://freeWebsite.Design
	Created by: Sajaan Matharu | https://matharu.io | @matharuio

	Comments, questions, bugs or feedback?
	Message me on twitter @matharuio, or through the contact link on https://freeWebsite.Design. 



License ------

	- Licensed Via Creative Commons Attribution 4.0 International
	- https://creativecommons.org/licenses/by/4.0/legalcode




Credit ------

	Thanks to everybody involved for the time and energy you all put into your respective works <3.

	Libraries
		JS
		- https://jquery.com/
		- https://greensock.com/gsap
		- https://threejs.org/

		CSS
		- https://necolas.github.io/normalize.css/
	

	Icons
		- https://fontawesome.com/


	Images
		- https://unsplash.com/@baileyzindel

	Email
		- https://formspree.io

	Fonts
		- https://fonts.google.com
	